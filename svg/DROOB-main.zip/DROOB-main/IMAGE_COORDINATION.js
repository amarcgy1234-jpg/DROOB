/**
 * IMAGE COORDINATION GUIDE
 * تنسيق الصور بأبعاد متساوية
 * 
 * Standardized dimensions system for all project images
 * نظام أبعاد موحد لجميع صور المشروع
 */

// ============================================
// 1. IMAGE DIMENSIONS STANDARD
// ============================================

const IMAGE_STANDARDS = {
    // Logo Sizes
    logo: {
        small: { width: 32, height: 32, name: 'Logo - Extra Small' },
        medium: { width: 40, height: 40, name: 'Logo - Small' },
        large: { width: 48, height: 48, name: 'Logo - Medium' },
        hero: { width: 64, height: 64, name: 'Logo - Large' },
    },

    // Team Member Photos
    team: {
        thumbnail: { width: 120, height: 120, name: 'Team - Thumbnail', ratio: '1:1' },
        card: { width: 200, height: 200, name: 'Team - Card', ratio: '1:1' },
        large: { width: 300, height: 300, name: 'Team - Large', ratio: '1:1' },
    },

    // Hero Images
    hero: {
        mobile: { width: 320, height: 240, name: 'Hero - Mobile', ratio: '4:3' },
        tablet: { width: 600, height: 400, name: 'Hero - Tablet', ratio: '3:2' },
        desktop: { width: 1200, height: 600, name: 'Hero - Desktop', ratio: '2:1' },
        banner: { width: 1920, height: 800, name: 'Hero - Banner', ratio: '12:5' },
    },

    // Feature Icons
    icons: {
        small: { width: 24, height: 24, name: 'Icon - Small', ratio: '1:1' },
        medium: { width: 48, height: 48, name: 'Icon - Medium', ratio: '1:1' },
        large: { width: 64, height: 64, name: 'Icon - Large', ratio: '1:1' },
        xlarge: { width: 128, height: 128, name: 'Icon - XLarge', ratio: '1:1' },
    },

    // Social Media / Profile
    profile: {
        avatar: { width: 80, height: 80, name: 'Avatar - Small', ratio: '1:1' },
        thumbnail: { width: 150, height: 150, name: 'Avatar - Medium', ratio: '1:1' },
        full: { width: 300, height: 300, name: 'Avatar - Full', ratio: '1:1' },
    },

    // Cards / Thumbnails
    card: {
        small: { width: 200, height: 150, name: 'Card - Small', ratio: '4:3' },
        medium: { width: 300, height: 200, name: 'Card - Medium', ratio: '3:2' },
        large: { width: 400, height: 300, name: 'Card - Large', ratio: '4:3' },
    },
};

// ============================================
// 2. IMAGE PATHS CONFIGURATION
// ============================================

const IMAGE_PATHS = {
    // SVG Images
    svg: {
        logo: './svg/logo.svg',
        team: {
            omar: './svg/Omar Alsulaymi.svg',
            ahmed: './svg/Ahmed Alsalimi.svg',
            ammar: './svg/عمار ابوهدية.svg',
            abdulkarim: './svg/عبدالكريم الشنقيطي.svg',
            aseel: './svg/اسيل الشاعر.svg',
        },
    },

    // Future image directories (when adding raster images)
    images: {
        hero: './images/hero/',
        team: './images/team/',
        icons: './images/icons/',
        cards: './images/cards/',
    },

    // Base URL for different environments
    baseUrl: {
        development: '',
        production: '/assets/images/',
    },
};

// ============================================
// 3. IMAGE COMPONENT CLASS
// ============================================

/**
 * Standardized Image Component
 * تكوين صور موحدة
 */
class ImageComponent {
    /**
     * Create an image element with standard dimensions
     * @param {string} src - Image source path
     * @param {string} type - Image type (logo, team, hero, icon, etc.)
     * @param {string} size - Size variant (small, medium, large, etc.)
     * @param {object} options - Additional options
     */
    static create(src, type, size = 'medium', options = {}) {
        const standards = IMAGE_STANDARDS[type];
        
        if (!standards) {
            console.error(`Image type "${type}" not found in standards`);
            return null;
        }

        const dims = standards[size];
        if (!dims) {
            console.error(`Size "${size}" not available for type "${type}"`);
            return null;
        }

        const img = document.createElement('img');
        img.src = src;
        img.alt = options.alt || dims.name;
        img.width = dims.width;
        img.height = dims.height;
        
        // Add classes
        if (options.className) {
            img.className = options.className;
        } else {
            img.className = `image-${type} image-${size}`;
        }

        // Add loading attribute for performance
        img.loading = options.loading || 'lazy';

        // Add srcset for responsive images
        if (options.srcset) {
            img.srcset = options.srcset;
        }

        // Add custom attributes
        if (options.attributes) {
            Object.entries(options.attributes).forEach(([key, value]) => {
                img.setAttribute(key, value);
            });
        }

        return img;
    }

    /**
     * Create a picture element with multiple sources
     * @param {object} sources - Image sources for different formats
     * @param {string} fallback - Fallback image source
     * @param {object} options - Additional options
     */
    static createPicture(sources, fallback, options = {}) {
        const picture = document.createElement('picture');

        // Add WebP source for modern browsers
        if (sources.webp) {
            const webpSource = document.createElement('source');
            webpSource.srcset = sources.webp;
            webpSource.type = 'image/webp';
            picture.appendChild(webpSource);
        }

        // Add JPEG source
        if (sources.jpeg) {
            const jpegSource = document.createElement('source');
            jpegSource.srcset = sources.jpeg;
            jpegSource.type = 'image/jpeg';
            picture.appendChild(jpegSource);
        }

        // Fallback image
        const img = document.createElement('img');
        img.src = fallback;
        img.alt = options.alt || 'Image';
        img.loading = options.loading || 'lazy';

        if (options.className) {
            img.className = options.className;
        }

        picture.appendChild(img);
        return picture;
    }
}

// ============================================
// 4. CSS CLASSES FOR IMAGE SIZING
// ============================================

/**
 * Generate CSS for image standardization
 * في HTML: استخدم هذه الأنماط
 */
const generateImageCSS = () => {
    return `
/* Logo Sizes */
.image-logo.image-small { width: 32px; height: 32px; }
.image-logo.image-medium { width: 40px; height: 40px; }
.image-logo.image-large { width: 48px; height: 48px; }
.image-logo.image-hero { width: 64px; height: 64px; }

/* Team Member Photos */
.image-team.image-thumbnail { width: 120px; height: 120px; border-radius: 12px; }
.image-team.image-card { width: 200px; height: 200px; border-radius: 14px; }
.image-team.image-large { width: 300px; height: 300px; border-radius: 16px; }

/* Hero Images */
.image-hero.image-mobile { width: 100%; max-width: 320px; height: 240px; object-fit: cover; }
.image-hero.image-tablet { width: 100%; max-width: 600px; height: 400px; object-fit: cover; }
.image-hero.image-desktop { width: 100%; max-width: 1200px; height: 600px; object-fit: cover; }
.image-hero.image-banner { width: 100%; max-width: 1920px; height: 800px; object-fit: cover; }

/* Icons */
.image-icons.image-small { width: 24px; height: 24px; }
.image-icons.image-medium { width: 48px; height: 48px; }
.image-icons.image-large { width: 64px; height: 64px; }
.image-icons.image-xlarge { width: 128px; height: 128px; }

/* Avatars */
.image-profile.image-avatar { width: 80px; height: 80px; border-radius: 50%; }
.image-profile.image-thumbnail { width: 150px; height: 150px; border-radius: 50%; }
.image-profile.image-full { width: 300px; height: 300px; border-radius: 50%; }

/* Cards */
.image-card.image-small { width: 200px; height: 150px; object-fit: cover; border-radius: 8px; }
.image-card.image-medium { width: 300px; height: 200px; object-fit: cover; border-radius: 10px; }
.image-card.image-large { width: 400px; height: 300px; object-fit: cover; border-radius: 12px; }

/* Common Image Styles */
img {
    display: block;
    max-width: 100%;
    height: auto;
    background-color: #f0f0f0;
    font-family: 'Cairo', sans-serif;
    color: #666;
}

/* SVG Specific */
img[src$=".svg"] {
    background-color: transparent;
    width: auto;
}

/* Responsive Images */
@media (max-width: 992px) {
    .image-hero.image-desktop { max-width: 100%; height: auto; }
    .image-hero.image-banner { max-width: 100%; height: auto; }
}

@media (max-width: 640px) {
    .image-team.image-large { width: 200px; height: 200px; }
    .image-hero.image-tablet { height: auto; }
}
`;
};

// ============================================
// 5. RESPONSIVE IMAGE HELPER
// ============================================

class ResponsiveImageHelper {
    /**
     * Generate srcset attribute for responsive images
     * @param {string} basePath - Base path for images
     * @param {string} extension - File extension
     * @returns {string} srcset attribute value
     */
    static generateSrcset(basePath, extension = 'jpg') {
        return `
            ${basePath}_small.${extension} 320w,
            ${basePath}_medium.${extension} 768w,
            ${basePath}_large.${extension} 1200w,
            ${basePath}_xlarge.${extension} 1920w
        `.trim().replace(/\n\s+/g, ', ');
    }

    /**
     * Get optimal image size based on device
     * @returns {string} size attribute value
     */
    static getOptimalSize() {
        const width = window.innerWidth;
        
        if (width < 640) return '100vw';
        if (width < 992) return '80vw';
        if (width < 1400) return '70vw';
        return '60vw';
    }

    /**
     * Calculate image dimensions based on aspect ratio
     * @param {string} aspectRatio - Aspect ratio (e.g., "16:9", "4:3", "1:1")
     * @param {number} width - Width in pixels
     * @returns {object} { width, height }
     */
    static calculateDimensions(aspectRatio, width) {
        const [ratioWidth, ratioHeight] = aspectRatio.split(':').map(Number);
        const height = (width * ratioHeight) / ratioWidth;
        return { width, height };
    }

    /**
     * Create lazy loading observer
     * @param {string} selector - CSS selector for images
     */
    static initLazyLoading(selector = 'img[loading="lazy"]') {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.add('loaded');
                        observer.unobserve(img);
                    }
                });
            });

            document.querySelectorAll(selector).forEach(img => {
                imageObserver.observe(img);
            });
        }
    }
}

// ============================================
// 6. IMAGE VALIDATION & OPTIMIZATION
// ============================================

class ImageValidator {
    /**
     * Validate image dimensions
     * @param {HTMLImageElement} img - Image element
     * @param {number} expectedWidth - Expected width
     * @param {number} expectedHeight - Expected height
     * @returns {boolean} Valid or not
     */
    static validateDimensions(img, expectedWidth, expectedHeight) {
        if (img.width !== expectedWidth || img.height !== expectedHeight) {
            console.warn(
                `Image dimension mismatch: expected ${expectedWidth}x${expectedHeight}, got ${img.width}x${img.height}`
            );
            return false;
        }
        return true;
    }

    /**
     * Check image file size
     * @param {File} file - Image file
     * @param {number} maxSize - Maximum size in MB
     * @returns {boolean} Valid or not
     */
    static validateFileSize(file, maxSize = 1) {
        const maxBytes = maxSize * 1024 * 1024;
        if (file.size > maxBytes) {
            console.warn(
                `Image file too large: ${(file.size / 1024 / 1024).toFixed(2)}MB > ${maxSize}MB`
            );
            return false;
        }
        return true;
    }

    /**
     * Validate image format
     * @param {File} file - Image file
     * @param {array} allowedFormats - Allowed formats (e.g., ['jpg', 'png', 'webp'])
     * @returns {boolean} Valid or not
     */
    static validateFormat(file, allowedFormats = ['jpg', 'png', 'svg', 'webp']) {
        const extension = file.name.split('.').pop().toLowerCase();
        if (!allowedFormats.includes(extension)) {
            console.warn(`Invalid image format: ${extension}`);
            return false;
        }
        return true;
    }
}

// ============================================
// 7. HTML USAGE EXAMPLES
// ============================================

/**
 * في HTML:
 * 
 * <!-- Logo الصغير -->
 * <img src="svg/logo.svg" alt="دروب" class="image-logo image-small" />
 * 
 * <!-- صورة فريق -->
 * <img 
 *     src="svg/Omar Alsulaymi.svg" 
 *     alt="Omar Alsulaymi"
 *     class="image-team image-card"
 *     loading="lazy"
 * />
 * 
 * <!-- صورة بـ srcset -->
 * <img 
 *     src="images/hero-medium.jpg"
 *     srcset="
 *         images/hero-small.jpg 320w,
 *         images/hero-medium.jpg 768w,
 *         images/hero-large.jpg 1200w"
 *     sizes="(max-width: 640px) 100vw,
 *            (max-width: 992px) 80vw,
 *            70vw"
 *     alt="صورة البطل"
 *     loading="lazy"
 *     class="image-hero image-desktop"
 * />
 * 
 * <!-- Picture Element مع عدة تنسيقات -->
 * <picture>
 *     <source srcset="images/hero.webp" type="image/webp" />
 *     <source srcset="images/hero.jpg" type="image/jpeg" />
 *     <img src="images/hero.jpg" alt="صورة البطل" />
 * </picture>
 */

// ============================================
// 8. JAVASCRIPT USAGE EXAMPLES
// ============================================

/**
 * أمثلة الاستخدام في JavaScript
 * 
 * // إنشاء صورة Logo
 * const logo = ImageComponent.create(
 *     './svg/logo.svg',
 *     'logo',
 *     'medium',
 *     { alt: 'شعار دروب' }
 * );
 * document.querySelector('.navbar').appendChild(logo);
 * 
 * // إنشاء صورة فريق
 * const teamMember = ImageComponent.create(
 *     './svg/Omar Alsulaymi.svg',
 *     'team',
 *     'card',
 *     {
 *         alt: 'Omar Alsulaymi',
 *         className: 'team-member-photo'
 *     }
 * );
 * 
 * // إنشاء صورة بـ picture element
 * const heroPicture = ImageComponent.createPicture(
 *     {
 *         webp: 'images/hero.webp',
 *         jpeg: 'images/hero.jpg'
 *     },
 *     'images/hero.jpg',
 *     { alt: 'صورة البطل' }
 * );
 * 
 * // تهيئة Lazy Loading
 * ResponsiveImageHelper.initLazyLoading();
 * 
 * // حساب الأبعاد
 * const dims = ResponsiveImageHelper.calculateDimensions('16:9', 1200);
 * console.log(dims); // { width: 1200, height: 675 }
 * 
 * // إنشاء srcset
 * const srcset = ResponsiveImageHelper.generateSrcset('images/hero', 'jpg');
 * 
 * // التحقق من صحة الصورة
 * const valid = ImageValidator.validateDimensions(img, 200, 200);
 */

// ============================================
// 9. CURRENT PROJECT IMAGES
// ============================================

/**
 * صور المشروع الحالية
 * Current Project Images
 */
const PROJECT_IMAGES = {
    logos: {
        main: {
            path: './svg/logo.svg',
            type: 'svg',
            standard: { width: '40px', height: '40px' },
            current: 'flexible (SVG)',
            recommendation: 'مربع 40x40 أو أكبر',
        },
    },

    team: {
        omar: {
            path: './svg/Omar Alsulaymi.svg',
            type: 'svg',
            standard: { width: '200px', height: '200px' },
            current: 'flexible (SVG)',
            recommendation: 'مربع 200x200 للكارت',
        },
        ahmed: {
            path: './svg/Ahmed Alsalimi.svg',
            type: 'svg',
            standard: { width: '200px', height: '200px' },
            current: 'flexible (SVG)',
            recommendation: 'مربع 200x200 للكارت',
        },
        ammar: {
            path: './svg/عمار ابوهدية.svg',
            type: 'svg',
            standard: { width: '200px', height: '200px' },
            current: 'flexible (SVG)',
            recommendation: 'مربع 200x200 للكارت',
        },
        abdulkarim: {
            path: './svg/عبدالكريم الشنقيطي.svg',
            type: 'svg',
            standard: { width: '200px', height: '200px' },
            current: 'flexible (SVG)',
            recommendation: 'مربع 200x200 للكارت',
        },
        aseel: {
            path: './svg/اسيل الشاعر.svg',
            type: 'svg',
            standard: { width: '200px', height: '200px' },
            current: 'flexible (SVG)',
            recommendation: 'مربع 200x200 للكارت',
        },
    },
};

// ============================================
// 10. RECOMMENDATIONS
// ============================================

/**
 * التوصيات:
 * Recommendations:
 * 
 * 1. استخدم أبعاد موحدة لجميع الصور
 *    Use consistent dimensions for all images
 * 
 * 2. استخدم SVG للأيقونات والشعارات
 *    Use SVG for icons and logos (scalable)
 * 
 * 3. استخدم WebP مع JPEG fallback
 *    Use WebP format with JPEG fallback
 * 
 * 4. طبّق lazy loading للصور الكبيرة
 *    Implement lazy loading for large images
 * 
 * 5. استخدم srcset للصور المتجاوبة
 *    Use srcset for responsive images
 * 
 * 6. ضغط الصور بدون فقدان الجودة
 *    Compress images without quality loss
 * 
 * 7. استخدم object-fit للصور في الحاويات
 *    Use object-fit for images in containers
 * 
 * 8. اختبر على أجهزة وأحجام مختلفة
 *    Test on different devices and sizes
 */

// ============================================
// 11. CONFIGURATION EXPORT
// ============================================

const ImageConfig = {
    standards: IMAGE_STANDARDS,
    paths: IMAGE_PATHS,
    component: ImageComponent,
    responsive: ResponsiveImageHelper,
    validator: ImageValidator,
    current: PROJECT_IMAGES,
    css: generateImageCSS(),
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ImageConfig;
}

console.log('✅ Image Coordination System Loaded');
console.log('📐 Image Standards:', IMAGE_STANDARDS);
console.log('🖼️ Current Images:', PROJECT_IMAGES);
