/**
 * LOGIN PAGE - JAVASCRIPT FUNCTIONALITY
 * Modern, Responsive Login System with RTL Support
 * Features: Form Validation, Password Toggle, Error Handling, Mobile Menu
 */

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Debounce function to prevent excessive function calls
 * @param {Function} func - Function to debounce
 * @param {number} delay - Delay in milliseconds
 */
const debounce = (func, delay) => {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, delay);
    };
};

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean}
 */
const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

/**
 * Check if string is a valid Saudi ID (10 digits)
 * @param {string} id - ID to validate
 * @returns {boolean}
 */
const isValidSaudiID = (id) => {
    return /^\d{10}$/.test(id.replace(/\s/g, ''));
};

/**
 * Trim and normalize input
 * @param {string} value - Value to normalize
 * @returns {string}
 */
const normalizeInput = (value) => {
    return value.trim().replace(/\s+/g, ' ');
};

// ============================================
// DOM ELEMENTS CACHE
// ============================================

const DOM = {
    // Navigation
    navbar: document.querySelector('.navbar'),
    mobileMenuToggle: document.getElementById('mobileMenuToggle'),
    navLinks: document.getElementById('navLinks'),

    // Form Elements
    loginForm: document.getElementById('loginForm'),
    usernameInput: document.getElementById('username'),
    passwordInput: document.getElementById('password'),
    rememberMeCheckbox: document.getElementById('rememberMe'),
    loginBtn: document.getElementById('loginBtn'),

    // Error Display Elements
    usernameError: document.getElementById('usernameError'),
    passwordError: document.getElementById('passwordError'),
    formAlert: document.getElementById('formAlert'),

    // Buttons
    togglePasswordBtn: document.getElementById('togglePassword'),
    absherBtn: document.getElementById('absherBtn'),

    // Footer
    yearElement: document.getElementById('year'),
};

// ============================================
// FORM VALIDATION
// ============================================

class FormValidator {
    /**
     * Validate username (can be email or Saudi ID)
     * @param {string} username
     * @returns {object} - { isValid: boolean, error: string }
     */
    static validateUsername(username) {
        const normalized = normalizeInput(username);

        if (!normalized) {
            return {
                isValid: false,
                error: 'الرجاء إدخال رقم الهوية أو البريد الإلكتروني',
            };
        }

        if (normalized.length < 3) {
            return {
                isValid: false,
                error: 'الإدخال قصير جدًا',
            };
        }

        const isEmail = isValidEmail(normalized);
        const isID = isValidSaudiID(normalized);

        if (!isEmail && !isID) {
            return {
                isValid: false,
                error: 'أدخل بريدًا إلكترونيًا صحيحًا أو رقم هوية من 10 أرقام',
            };
        }

        return { isValid: true, error: '' };
    }

    /**
     * Validate password
     * @param {string} password
     * @returns {object} - { isValid: boolean, error: string }
     */
    static validatePassword(password) {
        if (!password) {
            return {
                isValid: false,
                error: 'الرجاء إدخال كلمة المرور',
            };
        }

        if (password.length < 6) {
            return {
                isValid: false,
                error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
            };
        }

        return { isValid: true, error: '' };
    }

    /**
     * Validate entire form
     * @returns {boolean}
     */
    static validateForm() {
        let isFormValid = true;

        // Validate username
        const usernameValidation = this.validateUsername(DOM.usernameInput.value);
        if (!usernameValidation.isValid) {
            FormDisplay.showError('username', usernameValidation.error);
            isFormValid = false;
        } else {
            FormDisplay.clearError('username');
        }

        // Validate password
        const passwordValidation = this.validatePassword(DOM.passwordInput.value);
        if (!passwordValidation.isValid) {
            FormDisplay.showError('password', passwordValidation.error);
            isFormValid = false;
        } else {
            FormDisplay.clearError('password');
        }

        return isFormValid;
    }
}

// ============================================
// FORM DISPLAY & UI MANAGEMENT
// ============================================

class FormDisplay {
    /**
     * Show error message for a field
     * @param {string} fieldType - 'username' or 'password'
     * @param {string} message - Error message
     */
    static showError(fieldType, message) {
        const errorElement = fieldType === 'username' ? DOM.usernameError : DOM.passwordError;
        const inputElement = fieldType === 'username' ? DOM.usernameInput : DOM.passwordInput;

        if (errorElement) {
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }

        if (inputElement) {
            inputElement.setAttribute('aria-invalid', 'true');
        }
    }

    /**
     * Clear error message for a field
     * @param {string} fieldType - 'username' or 'password'
     */
    static clearError(fieldType) {
        const errorElement = fieldType === 'username' ? DOM.usernameError : DOM.passwordError;
        const inputElement = fieldType === 'username' ? DOM.usernameInput : DOM.passwordInput;

        if (errorElement) {
            errorElement.classList.remove('show');
            errorElement.textContent = '';
        }

        if (inputElement) {
            inputElement.setAttribute('aria-invalid', 'false');
        }
    }

    /**
     * Show alert message (error or success)
     * @param {string} message - Message to display
     * @param {string} type - 'error' or 'success'
     */
    static showAlert(message, type = 'error') {
        DOM.formAlert.textContent = message;
        DOM.formAlert.className = `form-alert show ${type}`;

        // Auto-hide success messages after 3 seconds
        if (type === 'success') {
            setTimeout(() => {
                DOM.formAlert.classList.remove('show');
            }, 3000);
        }

        // Scroll to alert for mobile
        if (window.innerWidth <= 640) {
            DOM.formAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    /**
     * Clear all alert messages
     */
    static clearAlert() {
        DOM.formAlert.classList.remove('show');
        DOM.formAlert.textContent = '';
    }

    /**
     * Set button loading state
     * @param {boolean} isLoading
     */
    static setButtonLoading(isLoading) {
        if (isLoading) {
            DOM.loginBtn.classList.add('loading');
            DOM.loginBtn.disabled = true;
            DOM.usernameInput.disabled = true;
            DOM.passwordInput.disabled = true;
        } else {
            DOM.loginBtn.classList.remove('loading');
            DOM.loginBtn.disabled = false;
            DOM.usernameInput.disabled = false;
            DOM.passwordInput.disabled = false;
        }
    }
}

// ============================================
// PASSWORD TOGGLE FUNCTIONALITY
// ============================================

class PasswordToggle {
    /**
     * Initialize password toggle button
     */
    static init() {
        if (!DOM.togglePasswordBtn) return;

        DOM.togglePasswordBtn.addEventListener('click', () => {
            this.togglePasswordVisibility();
        });
    }

    /**
     * Toggle password visibility
     */
    static togglePasswordVisibility() {
        const isPasswordVisible = DOM.passwordInput.type === 'text';

        DOM.passwordInput.type = isPasswordVisible ? 'password' : 'text';
        DOM.togglePasswordBtn.textContent = isPasswordVisible ? '👁️' : '👁️‍🗨️';
        DOM.togglePasswordBtn.setAttribute(
            'aria-label',
            isPasswordVisible ? 'إظهار كلمة المرور' : 'إخفاء كلمة المرور'
        );
    }
}

// ============================================
// LOCAL STORAGE MANAGEMENT
// ============================================

class LocalStorageManager {
    static KEYS = {
        REMEMBER_ME: 'droob_remember_me',
        SAVED_USERNAME: 'droob_saved_username',
    };

    /**
     * Save login preferences
     * @param {string} username
     * @param {boolean} rememberMe
     */
    static saveLoginPreferences(username, rememberMe) {
        if (rememberMe) {
            localStorage.setItem(this.KEYS.REMEMBER_ME, 'true');
            localStorage.setItem(this.KEYS.SAVED_USERNAME, normalizeInput(username));
        } else {
            localStorage.removeItem(this.KEYS.REMEMBER_ME);
            localStorage.removeItem(this.KEYS.SAVED_USERNAME);
        }
    }

    /**
     * Load saved login preferences
     */
    static loadLoginPreferences() {
        const rememberMe = localStorage.getItem(this.KEYS.REMEMBER_ME) === 'true';
        const savedUsername = localStorage.getItem(this.KEYS.SAVED_USERNAME);

        if (rememberMe && savedUsername) {
            DOM.usernameInput.value = savedUsername;
            DOM.rememberMeCheckbox.checked = true;
        }
    }

    /**
     * Clear saved login preferences
     */
    static clearLoginPreferences() {
        localStorage.removeItem(this.KEYS.REMEMBER_ME);
        localStorage.removeItem(this.KEYS.SAVED_USERNAME);
    }
}

// ============================================
// LOGIN FORM HANDLING
// ============================================

class LoginHandler {
    /**
     * Handle form submission
     * @param {Event} event
     */
    static async handleSubmit(event) {
        event.preventDefault();

        // Clear previous alerts
        FormDisplay.clearAlert();

        // Validate form
        if (!FormValidator.validateForm()) {
            FormDisplay.showAlert('الرجاء التحقق من البيانات المدخلة', 'error');
            return;
        }

        // Simulate API call
        await this.submitLogin();
    }

    /**
     * Simulate login API call
     */
    static async submitLogin() {
        FormDisplay.setButtonLoading(true);

        const username = DOM.usernameInput.value;
        const password = DOM.passwordInput.value;
        const rememberMe = DOM.rememberMeCheckbox.checked;

        try {
            // Simulate API delay
            await new Promise((resolve) => setTimeout(resolve, 1500));

            // Mock authentication
            // In production, this would be an actual API call
            if (this.isValidCredentials(username, password)) {
                // Save preferences
                LocalStorageManager.saveLoginPreferences(username, rememberMe);

                // Success feedback
                FormDisplay.showAlert('تم تسجيل الدخول بنجاح! جاري التوجيه...', 'success');

                // Simulate redirect after delay
                setTimeout(() => {
                    window.location.href = 'index.html';
                    // In production: redirect to dashboard
                }, 1500);
            } else {
                FormDisplay.showAlert('بيانات المستخدم أو كلمة المرور غير صحيحة', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            FormDisplay.showAlert(
                'حدث خطأ أثناء محاولة تسجيل الدخول. الرجاء المحاولة لاحقًا',
                'error'
            );
        } finally {
            FormDisplay.setButtonLoading(false);
        }
    }

    /**
     * Mock credential validation
     * In production, this would be handled by backend
     * @param {string} username
     * @param {string} password
     * @returns {boolean}
     */
    static isValidCredentials(username, password) {
        // Mock credentials for demo
        const mockCredentials = [
            { username: 'demo@example.com', password: '123456' },
            { username: '1234567890', password: '123456' },
        ];

        return mockCredentials.some(
            (cred) => cred.username === normalizeInput(username) && cred.password === password
        );
    }
}

// ============================================
// MOBILE MENU TOGGLE
// ============================================

class MobileMenuToggle {
    /**
     * Initialize mobile menu toggle
     */
    static init() {
        if (!DOM.mobileMenuToggle) return;

        DOM.mobileMenuToggle.addEventListener('click', () => {
            this.toggleMenu();
        });

        // Close menu when link is clicked
        document.querySelectorAll('.nav-links a').forEach((link) => {
            link.addEventListener('click', () => {
                this.closeMenu();
            });
        });

        // Close menu on window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 992) {
                this.closeMenu();
                DOM.mobileMenuToggle.classList.remove('active');
            }
        });
    }

    /**
     * Toggle mobile menu visibility
     */
    static toggleMenu() {
        DOM.mobileMenuToggle.classList.toggle('active');
        DOM.navLinks.classList.toggle('active');
    }

    /**
     * Close mobile menu
     */
    static closeMenu() {
        DOM.mobileMenuToggle.classList.remove('active');
        DOM.navLinks.classList.remove('active');
    }
}

// ============================================
// ABSHER INTEGRATION (Mock)
// ============================================

class AbsherIntegration {
    /**
     * Initialize Absher button
     */
    static init() {
        if (!DOM.absherBtn) return;

        DOM.absherBtn.addEventListener('click', () => {
            this.handleAbsherLogin();
        });
    }

    /**
     * Handle Absher login redirect
     * In production, this would redirect to Absher OAuth
     */
    static handleAbsherLogin() {
        FormDisplay.showAlert(
            'سيتم التوجيه إلى منصة أبشر الآمنة...', 
            'success'
        );

        // Mock redirect delay
        setTimeout(() => {
            // In production:
            // window.location.href = 'https://absher.sa/oauth/authorize?...';
            console.log('Redirecting to Absher...');
        }, 1500);
    }
}

// ============================================
// REAL-TIME VALIDATION
// ============================================

class RealTimeValidation {
    /**
     * Initialize real-time validation listeners
     */
    static init() {
        // Username validation on blur
        if (DOM.usernameInput) {
            DOM.usernameInput.addEventListener('blur', () => {
                const validation = FormValidator.validateUsername(DOM.usernameInput.value);
                if (!validation.isValid) {
                    FormDisplay.showError('username', validation.error);
                } else {
                    FormDisplay.clearError('username');
                }
            });

            // Clear error on input
            DOM.usernameInput.addEventListener('input', debounce(() => {
                if (DOM.usernameInput.value.trim()) {
                    FormDisplay.clearError('username');
                }
            }, 300));
        }

        // Password validation on blur
        if (DOM.passwordInput) {
            DOM.passwordInput.addEventListener('blur', () => {
                const validation = FormValidator.validatePassword(DOM.passwordInput.value);
                if (!validation.isValid) {
                    FormDisplay.showError('password', validation.error);
                } else {
                    FormDisplay.clearError('password');
                }
            });

            // Clear error on input
            DOM.passwordInput.addEventListener('input', debounce(() => {
                if (DOM.passwordInput.value.trim()) {
                    FormDisplay.clearError('password');
                }
            }, 300));
        }
    }
}

// ============================================
// INITIALIZATION
// ============================================

/**
 * Initialize all components on DOM ready
 */
function initializeApp() {
    // Check if all required DOM elements exist
    if (!DOM.loginForm || !DOM.usernameInput || !DOM.passwordInput) {
        console.error('Required form elements not found');
        return;
    }

    // Initialize components
    PasswordToggle.init();
    MobileMenuToggle.init();
    AbsherIntegration.init();
    RealTimeValidation.init();

    // Load saved preferences
    LocalStorageManager.loadLoginPreferences();

    // Set up form submission
    DOM.loginForm.addEventListener('submit', (e) => LoginHandler.handleSubmit(e));

    // Set current year in footer
    if (DOM.yearElement) {
        DOM.yearElement.textContent = new Date().getFullYear();
    }

    // Focus on username input by default
    setTimeout(() => {
        DOM.usernameInput.focus();
    }, 300);

    // Log initialization
    console.log('✓ Login page initialized successfully');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// ============================================
// PERFORMANCE OPTIMIZATION
// ============================================

// Prefetch DNS for external resources
if (document.head) {
    const link = document.createElement('link');
    link.rel = 'dns-prefetch';
    link.href = 'https://fonts.googleapis.com';
    document.head.appendChild(link);
}

// Track page performance
window.addEventListener('load', () => {
    if (window.performance && window.performance.timing) {
        const perfData = window.performance.timing;
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
        console.log(`Page load time: ${pageLoadTime}ms`);
    }
});

// ============================================
// ERROR HANDLING & LOGGING
// ============================================

window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    // In production, send to error tracking service
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled rejection:', event.reason);
    // In production, send to error tracking service
});
