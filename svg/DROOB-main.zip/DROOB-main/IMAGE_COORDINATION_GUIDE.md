# 📐 دليل تنسيق الصور بأبعاد متساوية
## Image Coordination Guide - Equal Dimensions

---

## 📋 المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [معايير الأبعاد](#معايير-الأبعاد)
3. [الاستخدام في HTML](#الاستخدام-في-html)
4. [الاستخدام في CSS](#الاستخدام-في-css)
5. [الاستخدام في JavaScript](#الاستخدام-في-javascript)
6. [أفضل الممارسات](#أفضل-الممارسات)
7. [الصور الحالية](#الصور-الحالية)

---

## 🎯 نظرة عامة

نظام موحد لإدارة جميع صور المشروع بأبعاد متساوية وموحدة، مما يضمن:

- ✅ اتساق بصري في جميع أنحاء الموقع
- ✅ تحميل صور أسرع وأكثر كفاءة
- ✅ سهولة الصيانة والتحديث
- ✅ توافقية مع جميع الأجهزة

---

## 📐 معايير الأبعاد

### الشعارات (Logos)

```
┌─────────────────────────────────────────────────────┐
│ الحجم        │ الأبعاد    │ الاستخدام                │
├─────────────────────────────────────────────────────┤
│ Extra Small  │ 32 × 32    │ عناصر صغيرة جداً         │
│ Small        │ 40 × 40    │ شريط التنقل             │
│ Medium       │ 48 × 48    │ الفوتر                 │
│ Large        │ 64 × 64    │ المحتوى الرئيسي        │
└─────────────────────────────────────────────────────┘
```

**الخصائص:**
- جميع الأحجام مربعة (1:1 ratio)
- تكبير خطي بنسبة 8px
- استخدام SVG للقابلية للتكبير

### صور الفريق (Team Members)

```
┌─────────────────────────────────────────────────────┐
│ الحجم        │ الأبعاد      │ الاستخدام               │
├─────────────────────────────────────────────────────┤
│ Thumbnail   │ 120 × 120   │ معاينة صغيرة            │
│ Card        │ 200 × 200   │ بطاقة الفريق (افتراضي)  │
│ Large       │ 300 × 300   │ عرض كامل                │
└─────────────────────────────────────────────────────┘
```

**الخصائص:**
- جميع الصور مربعة تماماً (1:1 ratio)
- نفس الأبعاد لجميع أعضاء الفريق
- زوايا مدورة لطيفة
- object-fit: cover للمحاذاة المثالية

### الأيقونات (Icons)

```
┌─────────────────────────────────────────────────────┐
│ الحجم        │ الأبعاد    │ الاستخدام                │
├─────────────────────────────────────────────────────┤
│ Small       │ 24 × 24    │ أيقونات نصية            │
│ Medium      │ 48 × 48    │ أيقونات عادية (افتراضي) │
│ Large       │ 64 × 64    │ أيقونات بارزة          │
│ XLarge      │ 128 × 128  │ أيقونات كبيرة جداً      │
└─────────────────────────────────────────────────────┘
```

**الخصائص:**
- جميع الأيقونات مربعة
- استخدام SVG للجودة المثالية
- محاذاة مركزية دائماً

### صور البطل (Hero Images)

```
┌──────────────────────────────────────────────────┐
│ الجهاز      │ الأبعاد       │ النسبة │ الاستخدام      │
├──────────────────────────────────────────────────┤
│ Mobile     │ 320 × 240    │ 4:3   │ هواتف ذكية    │
│ Tablet     │ 600 × 400    │ 3:2   │ أجهزة لوحية   │
│ Desktop    │ 1200 × 600   │ 2:1   │ أجهزة سطح     │
│ Banner     │ 1920 × 800   │ 12:5  │ عرض كامل      │
└──────────────────────────────────────────────────┘
```

**الخصائص:**
- نسب مختلفة حسب الجهاز
- متجاوبة تماماً
- object-fit: cover للملء الكامل

---

## 💻 الاستخدام في HTML

### استخدام بسيط

```html
<!-- شعار صغير -->
<img 
    src="svg/logo.svg" 
    alt="شعار دروب" 
    class="image-logo image-small" 
/>

<!-- شعار وسيط (الأكثر استخداماً) -->
<img 
    src="svg/logo.svg" 
    alt="شعار دروب" 
    class="image-logo image-medium" 
/>

<!-- صورة فريق -->
<img 
    src="svg/Omar Alsulaymi.svg" 
    alt="Omar Alsulaymi" 
    class="image-team image-card" 
    loading="lazy"
/>

<!-- أيقونة -->
<img 
    src="icons/feature.svg" 
    alt="ميزة" 
    class="image-icons image-large" 
/>
```

### استخدام متقدم مع Responsive

```html
<!-- صورة Hero متجاوبة -->
<img 
    src="images/hero-medium.jpg"
    srcset="
        images/hero-small.jpg 320w,
        images/hero-medium.jpg 768w,
        images/hero-large.jpg 1200w,
        images/hero-xlarge.jpg 1920w"
    sizes="(max-width: 640px) 100vw,
           (max-width: 992px) 80vw,
           70vw"
    alt="صورة البطل"
    loading="lazy"
    class="image-hero image-desktop"
/>

<!-- صورة بـ Picture Element -->
<picture>
    <source 
        srcset="images/hero.webp" 
        type="image/webp"
    />
    <source 
        srcset="images/hero.jpg" 
        type="image/jpeg"
    />
    <img 
        src="images/hero.jpg" 
        alt="صورة البطل"
        class="image-hero image-desktop"
    />
</picture>

<!-- Avatar دائري -->
<img 
    src="images/avatar.jpg" 
    alt="ملف التعريف" 
    class="image-avatar image-md" 
/>

<!-- Grid من صور الفريق -->
<div class="team-grid">
    <img 
        src="svg/Omar Alsulaymi.svg" 
        alt="Omar"
        loading="lazy"
    />
    <img 
        src="svg/Ahmed Alsalimi.svg" 
        alt="Ahmed"
        loading="lazy"
    />
    <!-- صور أخرى -->
</div>
```

---

## 🎨 الاستخدام في CSS

### الطريقة 1: استخدام الفئات المعرّفة

```css
/* في HTML، استخدم الفئات الجاهزة */
<img class="image-logo image-medium" />
<img class="image-team image-card" />
<img class="image-icons image-large" />

/* يتم تطبيق الأنماط تلقائياً */
```

### الطريقة 2: تخصيص الأبعاد

```css
/* تطبيق أبعاد مخصصة */
.my-custom-image {
    width: var(--team-md);
    height: var(--team-md);
    aspect-ratio: 1 / 1;
    object-fit: cover;
    border-radius: var(--radius-md);
}
```

### الطريقة 3: Grid موحد

```css
/* استخدام Grid للصور متساوية الحجم */
.team-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, var(--team-md));
    gap: var(--gap-lg);
}

.team-grid img {
    width: 100%;
    aspect-ratio: 1 / 1;
    object-fit: cover;
    border-radius: var(--radius-md);
}
```

### استخدام المتغيرات

```css
/* الوصول إلى المتغيرات المعرّفة */
:root {
    --logo-sm: 40px;
    --logo-md: 48px;
    --team-md: 200px;
    --icon-lg: 64px;
}

/* استخدام المتغيرات */
.logo { width: var(--logo-md); }
.team { width: var(--team-md); }
.icon { width: var(--icon-lg); }
```

---

## ⚙️ الاستخدام في JavaScript

### إنشاء صور موحدة

```javascript
// استيراد النظام
import ImageConfig from './IMAGE_COORDINATION.js';

// إنشاء شعار
const logo = ImageComponent.create(
    './svg/logo.svg',
    'logo',
    'medium',
    { alt: 'شعار دروب' }
);

// إنشاء صورة فريق
const teamPhoto = ImageComponent.create(
    './svg/Omar Alsulaymi.svg',
    'team',
    'card',
    { 
        alt: 'Omar Alsulaymi',
        className: 'team-member',
        loading: 'lazy'
    }
);

// إضافة إلى DOM
document.querySelector('header').appendChild(logo);
document.querySelector('.team-grid').appendChild(teamPhoto);
```

### تهيئة Lazy Loading

```javascript
// تفعيل Lazy Loading
ResponsiveImageHelper.initLazyLoading();

// أو للصور المخصصة
ResponsiveImageHelper.initLazyLoading('.custom-image');
```

### حساب الأبعاد

```javascript
// حساب أبعاد بناءً على النسبة
const dims = ResponsiveImageHelper.calculateDimensions('16:9', 1200);
console.log(dims); // { width: 1200, height: 675 }

// الحصول على حجم مثالي
const size = ResponsiveImageHelper.getOptimalSize();
console.log(size); // "70vw" أو حسب حجم الشاشة
```

### إنشاء Picture Element

```javascript
// إنشاء picture مع تنسيقات مختلفة
const picture = ImageComponent.createPicture(
    {
        webp: 'images/hero.webp',
        jpeg: 'images/hero.jpg'
    },
    'images/hero.jpg',
    { alt: 'صورة البطل' }
);

document.querySelector('.hero').appendChild(picture);
```

### التحقق من صحة الصور

```javascript
// التحقق من الأبعاد
const valid = ImageValidator.validateDimensions(
    img, 
    200,  // العرض المتوقع
    200   // الارتفاع المتوقع
);

// التحقق من حجم الملف
const fileValid = ImageValidator.validateFileSize(file, 1); // 1 MB

// التحقق من الصيغة
const formatValid = ImageValidator.validateFormat(
    file, 
    ['jpg', 'png', 'svg', 'webp']
);
```

---

## ✅ أفضل الممارسات

### 1. استخدم أبعاد موحدة دائماً

```html
<!-- ✅ صحيح - أبعاد موحدة -->
<img class="image-team image-card" />
<img class="image-team image-card" />

<!-- ❌ خطأ - أبعاد مختلفة -->
<img style="width: 200px; height: 200px;" />
<img style="width: 150px; height: 150px;" />
```

### 2. استخدم SVG للأيقونات والشعارات

```html
<!-- ✅ صحيح - SVG قابلة للتكبير -->
<img src="logo.svg" class="image-logo image-medium" />

<!-- ❌ تجنب - صور منخفضة الجودة -->
<img src="logo.png" class="image-logo image-medium" />
```

### 3. استخدم aspect-ratio

```css
/* ✅ صحيح - الحفاظ على النسبة */
.image-team {
    aspect-ratio: 1 / 1;
    object-fit: cover;
}

/* ❌ خطأ - قد تتشوه الصورة -->
.image-team {
    width: 200px;
    height: 250px; /* نسبة خاطئة */
}
```

### 4. طبّق Lazy Loading

```html
<!-- ✅ صحيح - تحميل كسول للأداء -->
<img src="team.jpg" loading="lazy" />

<!-- ❌ خطأ - تحميل جميع الصور دفعة واحدة -->
<img src="team.jpg" />
```

### 5. استخدم srcset للصور المتجاوبة

```html
<!-- ✅ صحيح - صور متجاوبة -->
<img 
    srcset="
        small.jpg 320w,
        medium.jpg 768w,
        large.jpg 1200w"
    src="medium.jpg"
/>

<!-- ❌ خطأ - صورة واحدة فقط -->
<img src="medium.jpg" />
```

### 6. ضغط الصور

```bash
# استخدم أدوات الضغط
# TinyPNG, ImageOptim, Squoosh

# قبل الضغط: 500 KB
# بعد الضغط: 50 KB
# جودة: متطابقة تقريباً
```

---

## 📁 الصور الحالية

### الشعارات

| الملف | الحالة | الملاحظات |
|------|--------|---------|
| `svg/logo.svg` | ✅ جاهز | شعار دروب الرسمي |

### صور الفريق

| الاسم | الملف | الحالة | الأبعاد المثالية |
|------|------|--------|------------------|
| Omar Alsulaymi | `svg/Omar Alsulaymi.svg` | ✅ جاهز | 200×200 |
| Ahmed Alsalimi | `svg/Ahmed Alsalimi.svg` | ✅ جاهز | 200×200 |
| Ammar Yahya | `svg/عمار ابوهدية.svg` | ✅ جاهز | 200×200 |
| Abdulkarim | `svg/عبدالكريم الشنقيطي.svg` | ✅ جاهز | 200×200 |
| Aseel Alshaer | `svg/اسيل الشاعر.svg` | ✅ جاهز | 200×200 |

---

## 🔗 ملفات النظام

### الملفات الرئيسية

```
/DROOB/
├── image-standards.css ........... أنماط الصور الموحدة
├── IMAGE_COORDINATION.js ......... نظام تنسيق الصور
├── IMAGE_DIMENSIONS.html ........ دليل الصور التفاعلي
├── IMAGE_COORDINATION_GUIDE.md .. هذا الدليل
```

### الاستخدام

1. **أضف CSS:**
   ```html
   <link rel="stylesheet" href="image-standards.css">
   ```

2. **أضف JavaScript:**
   ```html
   <script src="IMAGE_COORDINATION.js"></script>
   ```

3. **استخدم الفئات:**
   ```html
   <img class="image-logo image-medium" src="..." />
   ```

---

## 📊 مثال كامل

### HTML

```html
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="image-standards.css">
</head>
<body>
    <!-- Navbar -->
    <header class="navbar">
        <img 
            src="svg/logo.svg" 
            class="image-logo image-medium"
            alt="دروب"
        />
    </header>

    <!-- Team Section -->
    <section class="team">
        <div class="team-grid">
            <div>
                <img 
                    src="svg/Omar Alsulaymi.svg"
                    class="image-team image-card"
                    alt="Omar"
                    loading="lazy"
                />
                <h3>Omar Alsulaymi</h3>
            </div>
            <!-- صور أخرى -->
        </div>
    </section>

    <script src="IMAGE_COORDINATION.js"></script>
    <script>
        // تهيئة Lazy Loading
        ResponsiveImageHelper.initLazyLoading();
    </script>
</body>
</html>
```

### CSS

```css
/* استخدام الفئات الموحدة */
.navbar img {
    /* يتم تطبيق .image-logo.image-medium تلقائياً */
}

.team-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, var(--team-md));
    gap: var(--gap-lg);
}

.team-grid img {
    /* يتم تطبيق .image-team.image-card تلقائياً */
}
```

---

## 🎯 الخلاصة

| النقطة | الحل |
|--------|------|
| **الاتساق** | استخدم الفئات الموحدة في كل مكان |
| **الأداء** | طبّق Lazy Loading و srcset |
| **الجودة** | استخدم SVG للشعارات والأيقونات |
| **التوافقية** | اختبر على أجهزة مختلفة |
| **الصيانة** | استخدم متغيرات CSS |

---

**تم إعداد نظام تنسيق الصور الموحد بنجاح! ✅**

