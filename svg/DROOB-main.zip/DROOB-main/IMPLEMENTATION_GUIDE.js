/**
 * IMPLEMENTATION GUIDE - LOGIN SYSTEM BEST PRACTICES
 * دليل التطبيق - أفضل الممارسات لنظام تسجيل الدخول
 */

// ============================================
// 1. التكامل مع API الحقيقي
// ============================================

/**
 * مثال: استبدال المصادقة الوهمية بـ API حقيقي
 * Replace mock authentication with real API
 */

class RealLoginHandler {
    static async submitLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            // 1. إرسال طلب POST إلى API
            const response = await fetch('https://api.droob.gov.sa/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    // 'X-CSRF-Token': getCsrfToken(), // إضافة CSRF token
                },
                credentials: 'include', // لإرسال cookies
                body: JSON.stringify({
                    username: normalizeInput(username),
                    password: password,
                    rememberMe: document.getElementById('rememberMe').checked,
                }),
            });

            // 2. معالجة الاستجابة
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            // 3. حفظ التوكن (إذا استخدمت JWT)
            if (data.token) {
                localStorage.setItem('auth_token', data.token);
                // أو استخدم httpOnly cookie (أفضل)
            }

            // 4. التوجيه إلى الصفحة التالية
            window.location.href = data.redirectUrl || '/dashboard';

        } catch (error) {
            console.error('Login failed:', error);
            FormDisplay.showAlert(
                error.message || 'فشل تسجيل الدخول',
                'error'
            );
        } finally {
            FormDisplay.setButtonLoading(false);
        }
    }
}

// ============================================
// 2. معالجة الأخطاء المتقدمة
// ============================================

class AdvancedErrorHandling {
    /**
     * معالجة أنواع مختلفة من الأخطاء
     */
    static handleApiError(error) {
        if (error.response) {
            // الخادم رد برد حالة الخطأ
            switch (error.response.status) {
                case 401:
                    return 'بيانات المستخدم أو كلمة المرور غير صحيحة';
                case 429:
                    return 'عدد محاولات متكررة كبير. جرب لاحقًا';
                case 500:
                    return 'خطأ في الخادم. حاول مرة أخرى لاحقًا';
                default:
                    return `خطأ: ${error.response.statusText}`;
            }
        } else if (error.request) {
            // الطلب تم إرساله لكن لم يتم الرد
            return 'خطأ في الاتصال. تحقق من الإنترنت';
        } else {
            // خطأ في إعداد الطلب
            return 'خطأ غير متوقع. حاول مرة أخرى';
        }
    }

    /**
     * تسجيل الأخطاء لخدمة مراقبة
     */
    static logError(error, context = {}) {
        const errorData = {
            timestamp: new Date().toISOString(),
            message: error.message,
            stack: error.stack,
            userAgent: navigator.userAgent,
            url: window.location.href,
            context,
        };

        // إرسال إلى خدمة مراقبة (مثل Sentry, LogRocket)
        console.error('Error logged:', errorData);
        
        // في الإنتاج:
        // fetch('https://logs.droob.gov.sa/errors', {
        //     method: 'POST',
        //     body: JSON.stringify(errorData),
        // });
    }
}

// ============================================
// 3. التحقق المتقدم من صحة البيانات
// ============================================

class AdvancedValidation {
    /**
     * التحقق من رقم الهوية السعودية باستخدام Luhn Algorithm
     */
    static validateSaudiIDAdvanced(id) {
        const sanitized = id.replace(/\s/g, '');

        // يجب أن يكون 10 أرقام
        if (!/^\d{10}$/.test(sanitized)) {
            return false;
        }

        // تطبيق Luhn Algorithm
        let sum = 0;
        let digit;

        for (let i = 0; i < 10; i++) {
            digit = parseInt(sanitized[i], 10);

            if (i % 2 === 0) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }

            sum += digit;
        }

        return sum % 10 === 0;
    }

    /**
     * التحقق من قوة كلمة المرور
     */
    static validatePasswordStrength(password) {
        const strength = {
            score: 0,
            feedback: [],
        };

        // طول كلمة المرور
        if (password.length >= 8) strength.score++;
        else strength.feedback.push('أطول من 8 أحرف');

        // أحرف كبيرة
        if (/[A-Z]/.test(password)) strength.score++;
        else strength.feedback.push('يجب أن تحتوي على أحرف كبيرة');

        // أحرف صغيرة
        if (/[a-z]/.test(password)) strength.score++;
        else strength.feedback.push('يجب أن تحتوي على أحرف صغيرة');

        // أرقام
        if (/\d/.test(password)) strength.score++;
        else strength.feedback.push('يجب أن تحتوي على أرقام');

        // رموز خاصة
        if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password))
            strength.score++;
        else strength.feedback.push('يجب أن تحتوي على رموز خاصة');

        return strength;
    }

    /**
     * تصنيف قوة كلمة المرور
     */
    static getPasswordStrengthLevel(score) {
        if (score === 0) return { level: 'ضعيفة جداً', color: '#dc2626' };
        if (score === 1) return { level: 'ضعيفة', color: '#ea580c' };
        if (score === 2) return { level: 'متوسطة', color: '#f59e0b' };
        if (score === 3) return { level: 'قوية', color: '#10b981' };
        if (score === 4) return { level: 'قوية جداً', color: '#059669' };
        if (score >= 5) return { level: 'قوية جداً جداً', color: '#0f766e' };
    }
}

// ============================================
// 4. أمان الجلسات والتوكنات
// ============================================

class SessionManagement {
    /**
     * إدارة JWT Tokens
     */
    static saveToken(token) {
        // الطريقة الأفضل: httpOnly cookie (من الخادم)
        // لا تحفظ token في localStorage للأمان

        // إذا كنت مجبوراً على استخدام localStorage:
        localStorage.setItem('auth_token', token);
        
        // مع ضبط مدة الانتهاء
        const expiresIn = 3600000; // ساعة
        localStorage.setItem('token_expires', Date.now() + expiresIn);
    }

    /**
     * الحصول على التوكن
     */
    static getToken() {
        const token = localStorage.getItem('auth_token');
        const expires = localStorage.getItem('token_expires');

        // التحقق من انتهاء الصلاحية
        if (expires && Date.now() > expires) {
            this.clearToken();
            return null;
        }

        return token;
    }

    /**
     * حذف التوكن بأمان
     */
    static clearToken() {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('token_expires');
        
        // إرسال طلب logout إلى الخادم
        fetch('/api/auth/logout', { method: 'POST' });
    }

    /**
     * تحديث التوكن تلقائياً
     */
    static async refreshToken() {
        try {
            const response = await fetch('/api/auth/refresh', {
                method: 'POST',
                credentials: 'include',
            });

            if (!response.ok) {
                throw new Error('Token refresh failed');
            }

            const data = await response.json();
            this.saveToken(data.token);
            return true;
        } catch (error) {
            console.error('Token refresh error:', error);
            this.clearToken();
            window.location.href = '/login.html';
            return false;
        }
    }
}

// ============================================
// 5. Two-Factor Authentication (2FA)
// ============================================

class TwoFactorAuth {
    /**
     * طلب رمز التحقق
     */
    static async requestVerificationCode(username) {
        try {
            const response = await fetch('/api/auth/request-2fa', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username }),
            });

            if (!response.ok) throw new Error('Failed to request code');

            return await response.json();
        } catch (error) {
            console.error('2FA request error:', error);
            throw error;
        }
    }

    /**
     * التحقق من رمز 2FA
     */
    static async verifyCode(username, code) {
        try {
            const response = await fetch('/api/auth/verify-2fa', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, code }),
            });

            if (!response.ok) throw new Error('Invalid code');

            return await response.json();
        } catch (error) {
            console.error('2FA verification error:', error);
            throw error;
        }
    }

    /**
     * إنشاء صفحة إدخال رمز التحقق
     */
    static createVerificationUI() {
        return `
            <div class="two-fa-container">
                <h2>التحقق من الهوية</h2>
                <p>تم إرسال رمز تحقق إلى جهاتك المسجلة</p>
                
                <div class="form-group">
                    <label for="2fa-code">الرمز:</label>
                    <input 
                        type="text" 
                        id="2fa-code" 
                        maxlength="6"
                        inputmode="numeric"
                        placeholder="000000"
                        class="form-input"
                    />
                </div>
                
                <button type="button" class="btn-verify">
                    تحقق الآن
                </button>
                
                <p class="resend-text">
                    لم تستقبل الرمز؟
                    <button type="button" class="resend-link">أعد الإرسال</button>
                </p>
            </div>
        `;
    }
}

// ============================================
// 6. Social Login Integration
// ============================================

class SocialLogin {
    /**
     * تكامل Absher
     */
    static initAbsherLogin() {
        const clientId = 'YOUR_CLIENT_ID';
        const redirectUri = window.location.origin + '/auth/absher/callback';
        
        const absherUrl = 
            `https://absher.sa/oauth/authorize` +
            `?client_id=${clientId}` +
            `&response_type=code` +
            `&redirect_uri=${encodeURIComponent(redirectUri)}` +
            `&scope=profile`;

        window.location.href = absherUrl;
    }

    /**
     * معالجة رد الاتصال من Absher
     */
    static async handleAbsherCallback() {
        const params = new URLSearchParams(window.location.search);
        const code = params.get('code');

        if (!code) {
            FormDisplay.showAlert('فشل المصادقة عبر أبشر', 'error');
            return;
        }

        try {
            const response = await fetch('/api/auth/absher/callback', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code }),
            });

            const data = await response.json();
            SessionManagement.saveToken(data.token);
            window.location.href = '/dashboard';
        } catch (error) {
            FormDisplay.showAlert('خطأ في المصادقة', 'error');
        }
    }
}

// ============================================
// 7. التحليلات والمراقبة
// ============================================

class Analytics {
    /**
     * تتبع الأحداث المهمة
     */
    static trackEvent(eventName, eventData = {}) {
        const event = {
            name: eventName,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            ...eventData,
        };

        console.log('Analytics event:', event);

        // إرسال إلى خدمة التحليلات
        // navigator.sendBeacon('/api/analytics', JSON.stringify(event));
    }

    /**
     * تتبع محاولات تسجيل الدخول
     */
    static trackLoginAttempt(success, username) {
        this.trackEvent('login_attempt', {
            success,
            username: this.hashUsername(username),
            ipAddress: 'التحديث من الخادم',
        });
    }

    /**
     * تجزئة اسم المستخدم للخصوصية
     */
    static hashUsername(username) {
        // لا تخزن أسماء المستخدمين بشكل كامل
        return username.substring(0, 2) + '***';
    }

    /**
     * قياس أداء الصفحة
     */
    static measurePerformance() {
        window.addEventListener('load', () => {
            const perfData = performance.getEntriesByType('navigation')[0];

            this.trackEvent('page_performance', {
                domContentLoaded: perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart,
                pageLoadTime: perfData.loadEventEnd - perfData.loadEventStart,
                ttfb: perfData.responseEnd - perfData.responseStart,
            });
        });
    }
}

// ============================================
// 8. الاختبار الشامل
// ============================================

class Testing {
    /**
     * اختبار محاكاة الحالات المختلفة
     */
    static runTests() {
        console.log('🧪 Running login system tests...');

        // اختبار التحقق من البيانات
        this.testValidation();

        // اختبار معالجة الأخطاء
        this.testErrorHandling();

        // اختبار الأمان
        this.testSecurity();

        console.log('✅ All tests completed!');
    }

    /**
     * اختبارات التحقق من البيانات
     */
    static testValidation() {
        console.log('📝 Testing validation...');

        const tests = [
            {
                input: 'demo@example.com',
                expected: true,
                description: 'Valid email',
            },
            {
                input: '1234567890',
                expected: true,
                description: 'Valid Saudi ID',
            },
            {
                input: 'invalid-email',
                expected: false,
                description: 'Invalid email',
            },
        ];

        tests.forEach((test) => {
            const isValid =
                isValidEmail(test.input) || isValidSaudiID(test.input);
            const result = isValid === test.expected ? '✅' : '❌';
            console.log(`${result} ${test.description}`);
        });
    }

    /**
     * اختبارات معالجة الأخطاء
     */
    static testErrorHandling() {
        console.log('⚠️ Testing error handling...');

        try {
            throw new Error('Test error');
        } catch (error) {
            AdvancedErrorHandling.logError(error, { test: true });
            console.log('✅ Error logged successfully');
        }
    }

    /**
     * اختبارات الأمان
     */
    static testSecurity() {
        console.log('🔒 Testing security features...');

        // التحقق من عدم تخزين كلمات المرور
        if (localStorage.getItem('password')) {
            console.error('❌ Password stored in localStorage!');
        } else {
            console.log('✅ Passwords not stored locally');
        }

        // التحقق من وجود HTTPS في الإنتاج
        if (window.location.protocol === 'https:' || window.location.hostname === 'localhost') {
            console.log('✅ Using secure protocol');
        } else {
            console.warn('⚠️ Not using HTTPS in production!');
        }
    }
}

// ============================================
// 9. التطبيق العملي
// ============================================

// استخدام الاختبارات
if (window.location.hostname === 'localhost') {
    console.log('🚀 Development mode - Running tests');
    Testing.runTests();
}

// تتبع الأداء
Analytics.measurePerformance();

// ============================================
// 10. الملاحظات المهمة
// ============================================

/*
✅ BEST PRACTICES CHECKLIST:

أمان:
☑️ لا تخزن كلمات المرور في localStorage
☑️ استخدم HTTPS فقط في الإنتاج
☑️ طبّع جميع المدخلات
☑️ استخدم httpOnly cookies للتوكنات
☑️ طبّق Rate Limiting

الأداء:
☑️ ضغط الموارد (Minify)
☑️ Cache Browser
☑️ استخدم CDN
☑️ استخدم Service Workers
☑️ اختبر أداء الصفحة

الوصولية:
☑️ استخدم ARIA labels
☑️ دعم لوحة المفاتيح الكاملة
☑️ ألوان متباينة كافية
☑️ اختبر مع قارئات الشاشة

تجربة المستخدم:
☑️ تحقق فوري من البيانات
☑️ رسائل خطأ واضحة
☑️ تحميل سلس (Loading state)
☑️ دعم الأجهزة المختلفة
☑️ وقت استجابة سريع

SEO:
☑️ استخدم meta tags
☑️ hreflang للنسخ المختلفة
☑️ robots.txt مناسب
☑️ Sitemap
*/

console.log('✨ Login System - Production Ready Implementation Guide Loaded');
