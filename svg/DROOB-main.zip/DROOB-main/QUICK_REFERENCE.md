# 🚀 مرجع سريع - نظام تسجيل الدخول
## Quick Reference - Login System

---

## 📋 الملفات الرئيسية

| الملف | الوصف | الحجم |
|------|-------|--------|
| `login.html` | صفحة HTML | ~300 سطر |
| `login-style.css` | الأنماط والتصميم | ~900 سطر |
| `login-script.js` | المنطق والوظائف | ~700 سطر |

---

## ⚡ البدء السريع

```bash
# الطريقة الأسهل - فتح الملف مباشرة
open login.html

# أو باستخدام خادم محلي (الأفضل)
python -m http.server 8000
# ثم افتح: http://localhost:8000/login.html
```

---

## 🧪 بيانات الاختبار

```
البريد: demo@example.com
الهوية: 1234567890
كلمة المرور: 123456
```

---

## 🎨 الألوان الأساسية

```css
--primary: #0f766e;      /* أخضر - اللون الأساسي */
--accent: #2563eb;       /* أزرق - لون التركيز */
--danger: #dc2626;       /* أحمر - الأخطاء */
--success: #16a34a;      /* أخضر - النجاح */
--warning: #ea580c;      /* برتقالي - التحذيرات */
```

---

## 📱 نقاط الفصل (Breakpoints)

```css
/* أكبر من 1100px */ → أجهزة سطح المكتب الكبيرة
/* 992px - 1100px */ → أجهزة سطح المكتب
/* 640px - 992px */  → أجهزة لوحية
/* أقل من 640px */   → هواتف ذكية
```

---

## 🔧 الفئات الرئيسية (Classes)

### في JavaScript:
```javascript
FormValidator          // التحقق من البيانات
FormDisplay           // عرض الرسائل والأخطاء
LoginHandler          // معالجة تسجيل الدخول
PasswordToggle        // إظهار/إخفاء كلمة المرور
LocalStorageManager   // إدارة الذاكرة المحلية
MobileMenuToggle      // قائمة الهاتف المحمول
AbsherIntegration     // تكامل أبشر
RealTimeValidation    // التحقق الفوري
AdvancedErrorHandling // معالجة الأخطاء (في Guide)
SessionManagement     // إدارة الجلسات (في Guide)
TwoFactorAuth         // التحقق الثنائي (في Guide)
```

---

## 🎯 العناصر الرئيسية في HTML

```html
.navbar              → شريط التنقل العلوي
.login-section      → قسم تسجيل الدخول الرئيسي
.login-info         → لوحة المعلومات (يسار)
.login-form-wrapper → حاوية النموذج (يمين)
.login-card         → بطاقة النموذج
.login-form         → النموذج نفسه
.form-group         → مجموعة الإدخال
.form-input         → حقل الإدخال
.error-message      → رسالة الخطأ
.form-alert         → تنبيه النموذج العام
.btn-login          → زر تسجيل الدخول
.footer             → الفوتر السفلي
```

---

## 🔐 الدوال المهمة في JavaScript

### معالجة البيانات:
```javascript
FormValidator.validateUsername(username)    // التحقق من المستخدم
FormValidator.validatePassword(password)    // التحقق من كلمة المرور
FormValidator.validateForm()                // التحقق من النموذج كاملاً
```

### عرض الرسائل:
```javascript
FormDisplay.showError(field, message)       // عرض رسالة خطأ
FormDisplay.clearError(field)               // إخفاء رسالة الخطأ
FormDisplay.showAlert(message, type)        // عرض تنبيه
FormDisplay.setButtonLoading(isLoading)     // تعيين حالة التحميل
```

### معالجة تسجيل الدخول:
```javascript
LoginHandler.handleSubmit(event)            // معالجة الإرسال
LoginHandler.submitLogin()                  // محاكاة تسجيل الدخول
LoginHandler.isValidCredentials()           // التحقق من البيانات
```

---

## 🎨 تخصيص التصميم

### تغيير اللون الأساسي:
```css
:root {
    --primary: #YOUR_COLOR_HEX;
    --primary-dark: #DARKER_SHADE;
    --primary-light: #LIGHTER_SHADE;
}
```

### تغيير الخط:
```css
body {
    font-family: "Your Font", system-ui, sans-serif;
}
```

### تغيير المسافات:
```css
:root {
    --spacing-md: 20px;  /* من 16px إلى 20px */
    --spacing-lg: 32px;  /* من 24px إلى 32px */
}
```

---

## 🐛 حل المشاكل الشائعة

### المشكلة: الصفحة لا تحمل بشكل صحيح
```javascript
// افتح Console (F12) وتحقق من الأخطاء
// تأكد من أن جميع الملفات موجودة:
// - login.html
// - login-style.css
// - login-script.js
```

### المشكلة: النموذج لا يستجيب
```javascript
// افتح Console وانظر للأخطاء
// تأكد من تحميل JavaScript
// إعادة تحميل الصفحة (Ctrl+Shift+R)
```

### المشكلة: الألوان غير صحيحة
```css
/* تحقق من متغيرات CSS في browser.devtools */
/* افتح Elements > Computed > CSS Variables */
```

### المشكلة: الصفحة لا تستجيب على الهاتف
```javascript
// تأكد من وجود meta viewport:
// <meta name="viewport" content="width=device-width, initial-scale=1.0" />
```

---

## 📊 قائمة الفحص السريعة

### قبل الاختبار:
- [ ] جميع الملفات موجودة
- [ ] الملفات في نفس المجلد
- [ ] المتصفح محدث
- [ ] Console مفتوح للتحقق من الأخطاء

### أثناء الاختبار:
- [ ] اختبر على سطح المكتب
- [ ] اختبر على الهاتف
- [ ] اختبر بيانات صحيحة
- [ ] اختبر بيانات خاطئة
- [ ] اختبر الأزرار جميعها

### بعد الاختبار:
- [ ] لا توجد أخطاء في Console
- [ ] الأداء مقبولة
- [ ] جميع الوظائف تعمل
- [ ] التصميم صحيح على جميع الأحجام

---

## 🌐 الأختصارات الهامة

### في المتصفح:
```
F12                 → فتح Developer Tools
Ctrl+Shift+I        → فتح DevTools
Ctrl+Shift+M        → وضع الجهاز المحمول
Ctrl+Shift+C        → أداة التحديد
Ctrl+Shift+J        → فتح Console
Ctrl+Shift+K        → فتح Console (Firefox)
Tab                 → التنقل بين العناصر
Enter               → تفعيل العنصر المحدد
Space               → تفعيل الأزرار والخيارات
```

---

## 📈 نقاط الأداء المهمة

```
معدلات مقبولة:
├── وقت التحميل الأول: < 1 ثانية
├── وقت التفاعل: < 100ms
├── استقرار التخطيط: 99%+
└── نقاط الأداء: 90+/100
```

---

## 🔗 الروابط المهمة

```
المشروع:
├── الصفحة الرئيسية: index.html
├── صفحة تسجيل الدخول: login.html
└── التوثيق: LOGIN_README.md

الدعم:
├── البريد: support@droob.gov.sa
├── الموقع: https://droob.gov.sa
└── تقارير الأخطاء: bugs@droob.gov.sa
```

---

## 🎓 تعلم أكثر

### في المشروع:
- `LOGIN_README.md` → توثيق شاملة
- `IMPLEMENTATION_GUIDE.js` → أمثلة متقدمة
- `TESTING_GUIDE.md` → كيفية الاختبار

### موارد خارجية:
- [MDN Web Docs](https://developer.mozilla.org/)
- [CSS Tricks](https://css-tricks.com/)
- [JavaScript Info](https://javascript.info/)
- [WCAG Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)

---

## 📞 الدعم الفني

| المشكلة | الحل |
|--------|------|
| أين أجد الملفات؟ | في مجلد `DROOB` |
| كيف أختبر النظام؟ | شاهد `TESTING_GUIDE.md` |
| كيف أطور ميزات جديدة؟ | شاهد `IMPLEMENTATION_GUIDE.js` |
| هل هناك أخطاء؟ | افتح Console (F12) |
| كيف أنشر على الإنترنت؟ | استخدم خادم ويب مع HTTPS |

---

## ✨ نصائح مهمة

1. **استخدم خادم محلي** - الفتح المباشر قد يسبب مشاكل
2. **افتح Console دائماً** - للتحقق من الأخطاء
3. **اختبر على أجهزة حقيقية** - محاكيات ليست دقيقة تماماً
4. **استخدم HTTPS في الإنتاج** - أمان ضروري
5. **احفظ النسخ الاحتياطية** - قبل أي تعديلات كبيرة

---

## 🎉 تم!

أنت الآن جاهز للبدء! 

```
📁 ادفتح: login.html
🧪 اختبر باستخدام: demo@example.com / 123456
📚 اقرأ: LOGIN_README.md
🚀 ابدأ التطوير!
```

---

**آخر تحديث:** نوفمبر 2025
**الإصدار:** 1.0.0
**الحالة:** ✅ جاهز للاستخدام
